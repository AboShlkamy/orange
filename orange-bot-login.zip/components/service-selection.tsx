"use client"

import type { ServiceType } from "@/app/page"
import { Card, CardContent } from "@/components/ui/card"
import { Gift, Sparkles } from "lucide-react"

interface ServiceSelectionProps {
  onSelect: (service: ServiceType) => void
}

export function ServiceSelection({ onSelect }: ServiceSelectionProps) {
  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Header */}
      <div className="text-center space-y-3">
        <div className="w-20 h-20 bg-white rounded-full mx-auto flex items-center justify-center shadow-lg">
          <Gift className="w-10 h-10 text-orange-500" />
        </div>
        <h1 className="text-3xl font-bold text-white drop-shadow-md">
          خدمات اورنج المجانية
        </h1>
        <p className="text-white/90 text-lg">
          اختر الخدمة التي تريدها
        </p>
      </div>

      {/* Service Cards */}
      <div className="space-y-4">
        {/* 500MB Service */}
        <Card 
          className="cursor-pointer transition-all duration-300 hover:scale-[1.02] hover:shadow-xl border-2 border-transparent hover:border-orange-300 bg-white/95 backdrop-blur"
          onClick={() => onSelect("500mb")}
        >
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl flex items-center justify-center shadow-md">
                <span className="text-2xl font-bold text-white">500</span>
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-gray-800">500 ميجا اورنج</h3>
                <p className="text-gray-500 mt-1">متجدد كل 15 يوم</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="px-3 py-1 bg-orange-100 text-orange-600 rounded-full text-sm font-medium">
                    عرض خاص
                  </span>
                </div>
              </div>
              <div className="text-orange-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 250MB Service */}
        <Card 
          className="cursor-pointer transition-all duration-300 hover:scale-[1.02] hover:shadow-xl border-2 border-transparent hover:border-purple-300 bg-white/95 backdrop-blur"
          onClick={() => onSelect("250mb")}
        >
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-md">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-gray-800">250 ميجا فوازير</h3>
                <p className="text-gray-500 mt-1">هدية يومية مجانية</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="px-3 py-1 bg-purple-100 text-purple-600 rounded-full text-sm font-medium">
                    يوميا
                  </span>
                </div>
              </div>
              <div className="text-purple-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Footer */}
      <div className="text-center space-y-3">
        <div className="flex justify-center gap-3">
          <a 
            href="https://t.me/calm_aIways" 
            target="_blank" 
            rel="noopener noreferrer"
            className="px-4 py-2 bg-white/20 hover:bg-white/30 text-white rounded-full text-sm font-medium transition-colors backdrop-blur"
          >
            قناة كتابات
          </a>
          <a 
            href="https://t.me/abo_shlkamy" 
            target="_blank" 
            rel="noopener noreferrer"
            className="px-4 py-2 bg-white/20 hover:bg-white/30 text-white rounded-full text-sm font-medium transition-colors backdrop-blur"
          >
            المطور
          </a>
        </div>
        <p className="text-white/70 text-sm">
          لا تستخدمه فيما يغضب الله
        </p>
      </div>
    </div>
  )
}
