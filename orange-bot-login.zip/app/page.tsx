"use client"

import { useState } from "react"
import { ServiceSelection } from "@/components/service-selection"
import { ServiceForm } from "@/components/service-form"

export type ServiceType = "500mb" | "250mb" | null

export default function Home() {
  const [selectedService, setSelectedService] = useState<ServiceType>(null)

  const handleBack = () => {
    setSelectedService(null)
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-orange-500 via-orange-400 to-amber-400 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {selectedService === null ? (
          <ServiceSelection onSelect={setSelectedService} />
        ) : (
          <ServiceForm service={selectedService} onBack={handleBack} />
        )}
      </div>
    </main>
  )
}
