import { NextRequest, NextResponse } from "next/server"
import crypto from "crypto"

export async function POST(request: NextRequest) {
  try {
    const { phone, password } = await request.json()

    // Validate input
    if (!phone || !password) {
      return NextResponse.json(
        { success: false, message: "رقم الهاتف وكلمة المرور مطلوبان" },
        { status: 400 }
      )
    }

    if (!/^01[0-9]{9}$/.test(phone)) {
      return NextResponse.json(
        { success: false, message: "رقم الهاتف غير صحيح" },
        { status: 400 }
      )
    }

    // Step 1: Sign In
    const loginUrl = "https://services.orange.eg/SignIn.svc/SignInUser"
    const loginData = JSON.stringify({
      appVersion: "7.2.0",
      channel: {
        ChannelName: "MobinilAndMe",
        Password: "ig3yh*mk5l42@oj7QAR8yF",
      },
      dialNumber: phone,
      isAndroid: true,
      password: password,
    })

    const loginResponse = await fetch(loginUrl, {
      method: "POST",
      headers: {
        "net-msg-id": "61f91ede006159d16840827295301013",
        "x-microservice-name": "APMS",
        "Content-Type": "application/json; charset=UTF-8",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; SM-G981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Mobile Safari/537.36",
      },
      body: loginData,
    })

    const loginResult = await loginResponse.json()

    if (
      !loginResult?.SignInUserResult?.UserData?.UserID
    ) {
      return NextResponse.json(
        { success: false, message: "تاكد من الرقم وكلمة السر وحاول مرة اخرى" },
        { status: 400 }
      )
    }

    const userId = loginResult.SignInUserResult.UserData.UserID

    // Step 2: Generate Token
    const tokenUrl = "https://services.orange.eg/GetToken.svc/GenerateToken"
    const tokenData = JSON.stringify({
      appVersion: "2.9.8",
      channel: {
        ChannelName: "MobinilAndMe",
        Password: "ig3yh*mk5l42@oj7QAR8yF",
      },
      dialNumber: phone,
      isAndroid: true,
      password: password,
    })

    const tokenResponse = await fetch(tokenUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json; charset=UTF-8",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; SM-G981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Mobile Safari/537.36",
      },
      body: tokenData,
    })

    const tokenResult = await tokenResponse.json()

    if (!tokenResult?.GenerateTokenResult?.Token) {
      return NextResponse.json(
        { success: false, message: "فشل في الحصول على التوكن" },
        { status: 400 }
      )
    }

    const ctv = tokenResult.GenerateTokenResult.Token
    const key = ",{.c][o^uecnlkijh*.iomv:QzCFRcd;drof/zx}w;ls.e85T^#ASwa?=(lk"
    const htv = crypto
      .createHash("sha256")
      .update(ctv + key)
      .digest("hex")
      .toUpperCase()

    // Step 3: Redeem
    const redeemUrl = "https://services.orange.eg/APIs/Promotions/api/CAF/Redeem"
    const redeemData = JSON.stringify({
      Language: "ar",
      OSVersion: "Android7.0",
      PromoCode: "رمضان كريم",
      dial: phone,
      password: password,
      Channelname: "MobinilAndMe",
      ChannelPassword: "ig3yh*mk5l42@oj7QAR8yF",
    })

    const redeemResponse = await fetch(redeemUrl, {
      method: "POST",
      headers: {
        _ctv: ctv,
        _htv: htv,
        UserId: userId,
        "Content-Type": "application/json; charset=UTF-8",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; SM-G981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Mobile Safari/537.36",
      },
      body: redeemData,
    })

    const result = await redeemResponse.json()

    if (result?.ErrorDescription) {
      if (result.ErrorDescription === "Success") {
        return NextResponse.json({
          success: true,
          message: "تم اضافة 500 ميجا بايت بنجاح",
        })
      } else if (result.ErrorDescription === "User is redeemed before") {
        return NextResponse.json({
          success: false,
          warning: true,
          message: "تم استلام الهدية من قبل",
        })
      } else {
        return NextResponse.json({
          success: false,
          message: result.ErrorDescription,
        })
      }
    }

    return NextResponse.json({
      success: false,
      message: "حدث خطا غير متوقع",
    })
  } catch (error) {
    console.error("Error in redeem-500:", error)
    
    const errorMessage = error instanceof Error ? error.message : "Unknown error"
    
    if (errorMessage.includes("ECONNRESET") || errorMessage.includes("fetch failed")) {
      return NextResponse.json(
        {
          success: false,
          message: "مشكلة في الاتصال بالخادم. حاول مرة اخرى لاحقا",
        },
        { status: 503 }
      )
    }

    return NextResponse.json(
      { success: false, message: "حدث خطا اثناء المعالجة" },
      { status: 500 }
    )
  }
}
