import { NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { phone, password } = await request.json()

    // Validate input
    if (!phone || !password) {
      return NextResponse.json(
        { success: false, message: "رقم الهاتف وكلمة المرور مطلوبان" },
        { status: 400 }
      )
    }

    if (!/^01[0-9]{9}$/.test(phone)) {
      return NextResponse.json(
        { success: false, message: "رقم الهاتف غير صحيح" },
        { status: 400 }
      )
    }

    // Step 1: Sign In
    const signInUrl = "https://services.orange.eg/SignIn.svc/SignInUser"
    const signInData = JSON.stringify({
      appVersion: "9.0.1",
      channel: {
        ChannelName: "MobinilAndMe",
        Password: "ig3yh*mk5l42@oj7QAR8yF",
      },
      dialNumber: phone,
      isAndroid: true,
      lang: "ar",
      password: password,
    })

    const signInResponse = await fetch(signInUrl, {
      method: "POST",
      headers: {
        "User-Agent": "okhttp/4.10.0",
        Connection: "Keep-Alive",
        "Accept-Encoding": "gzip",
        "Content-Type": "application/json; charset=UTF-8",
      },
      body: signInData,
    })

    const signInResult = await signInResponse.json()

    if (!signInResult?.SignInUserResult?.AccessToken) {
      return NextResponse.json(
        { success: false, message: "رقم الهاتف او كلمة المرور غير صحيحة" },
        { status: 400 }
      )
    }

    const accessToken = signInResult.SignInUserResult.AccessToken

    // Step 2: Generate Token
    const generateUrl =
      "https://services.orange.eg/APIs/Profile/api/BasicAuthentication/Generate"
    const generateData = JSON.stringify({
      ChannelName: "MobinilAndMe",
      ChannelPassword: "ig3yh*mk5l42@oj7QAR8yF",
      Dial: phone,
      Language: "ar",
      Module: "0",
      Password: password,
    })

    const generateResponse = await fetch(generateUrl, {
      method: "POST",
      headers: {
        "User-Agent": "okhttp/4.10.0",
        Connection: "Keep-Alive",
        "Accept-Encoding": "gzip",
        "Content-Type": "application/json; charset=UTF-8",
        AppVersion: "9.0.1",
        OsVersion: "13",
        IsAndroid: "true",
        IsEasyLogin: "false",
        Token: accessToken,
      },
      body: generateData,
    })

    const generateResult = await generateResponse.json()

    if (!generateResult?.Token) {
      return NextResponse.json(
        { success: false, message: "فشل في انشاء رمز الدخول" },
        { status: 400 }
      )
    }

    const token = generateResult.Token

    // Step 3: Get Questions
    const questionsUrl =
      "https://services.orange.eg/APIs/Ramadan2024/api/RamadanOffers/Fawazeer/Questions"
    const questionsData = JSON.stringify({
      Dial: phone,
      Language: "ar",
      Token: token,
    })

    const questionsHeaders = {
      "User-Agent":
        "Mozilla/5.0 (Linux; Android 13; 21061119AG Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/139.0.7258.158 Mobile Safari/537.36",
      Accept: "application/json, text/plain, */*",
      "Accept-Encoding": "gzip, deflate, br, zstd",
      "Content-Type": "application/json",
      "sec-ch-ua-platform": '"Android"',
      "sec-ch-ua": '"Not;A=Brand";v="99", "Android WebView";v="139", "Chromium";v="139"',
      "sec-ch-ua-mobile": "?1",
      Origin: "https://services.orange.eg",
      "X-Requested-With": "com.orange.mobinilandmf",
      "Sec-Fetch-Site": "same-origin",
      "Sec-Fetch-Mode": "cors",
      "Sec-Fetch-Dest": "empty",
      "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
    }

    const questionsResponse = await fetch(questionsUrl, {
      method: "POST",
      headers: questionsHeaders,
      body: questionsData,
    })

    const questionsResult = await questionsResponse.json()

    // Check if already played today
    if (questionsResult?.ErrorCode === 1) {
      return NextResponse.json({
        success: false,
        warning: true,
        message: "انت دخلت على الفوازير النهارده. جرب بكره",
      })
    }

    if (!questionsResult?.Questions || questionsResult.Questions.length === 0) {
      return NextResponse.json({
        success: false,
        message: "لا توجد اسئلة متاحة حاليا",
      })
    }

    // Collect correct answers
    const answersList: Array<{ QuestionId: number; AnswerId: number }> = []

    for (const question of questionsResult.Questions) {
      for (const answer of question.Answers) {
        if (answer.IsCorrect === true) {
          answersList.push({
            QuestionId: answer.QuestionId,
            AnswerId: answer.Id,
          })
          break
        }
      }
    }

    if (answersList.length === 0) {
      return NextResponse.json({
        success: false,
        message: "لم يتم العثور على اجابات صحيحة",
      })
    }

    // Step 4: Submit Answers
    const submitUrl =
      "https://services.orange.eg/APIs/Ramadan2024/api/RamadanOffers/Fawazeer/Submit"
    const submitData = JSON.stringify({
      Dial: phone,
      Language: "ar",
      Token: token,
      Answers: answersList,
    })

    const submitResponse = await fetch(submitUrl, {
      method: "POST",
      headers: questionsHeaders,
      body: submitData,
    })

    const submitResult = await submitResponse.json()

    if (submitResult?.ErrorDescription === "FawazeerSuccess") {
      return NextResponse.json({
        success: true,
        message: "تم اضافة 250 ميجا بنجاح",
      })
    } else {
      return NextResponse.json({
        success: false,
        message: submitResult?.ErrorDescription || "حدث خطا غير متوقع",
      })
    }
  } catch (error) {
    console.error("Error in fawazeer:", error)

    const errorMessage = error instanceof Error ? error.message : "Unknown error"

    if (errorMessage.includes("ECONNRESET") || errorMessage.includes("fetch failed")) {
      return NextResponse.json(
        {
          success: false,
          message: "مشكلة في الاتصال بالخادم. حاول مرة اخرى لاحقا",
        },
        { status: 503 }
      )
    }

    return NextResponse.json(
      { success: false, message: "حدث خطا اثناء المعالجة" },
      { status: 500 }
    )
  }
}
